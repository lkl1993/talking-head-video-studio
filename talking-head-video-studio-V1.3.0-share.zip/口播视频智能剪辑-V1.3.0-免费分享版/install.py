"""Copy the skill into Codex's skill directory, then optionally prepare local dependencies."""
import argparse
from pathlib import Path
import os
import shutil
import subprocess
import sys
import venv

NAME='talking-head-video-studio'
SOURCE=Path(__file__).resolve().parent/NAME

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skills-dir',type=Path,default=Path.home()/'.agents'/'skills')
    parser.add_argument('--setup',action='store_true',help='install Python and Node packages from their registries')
    args=parser.parse_args()
    destination=args.skills_dir.resolve()/NAME
    if destination.exists() or destination.is_symlink():
        if not args.setup or (destination/'SKILL.md').read_bytes()!=(SOURCE/'SKILL.md').read_bytes():
            raise SystemExit(f'已有同名 Skill，未覆盖。先备份并移出技能目录。\n{destination}')
    else:
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(SOURCE,destination)
    print(f'口播视频智能剪辑已安装：{destination}',flush=True)
    if args.setup:
        setup(destination)

def setup(skill):
    if sys.version_info < (3,11):
        raise SystemExit('请安装 Python 3.11 或更新版本，建议 Python 3.12。')
    programs=['ffmpeg','ffprobe','node','npm','npx']
    missing=[name for name in programs if not shutil.which(name)]
    if missing:
        raise SystemExit('先安装工具并打开新的终端：'+', '.join(missing))
    node_version=subprocess.check_output(['node','-p','process.versions.node'],text=True).split('.')[0]
    if int(node_version)<24:
        raise SystemExit('这份安装教程使用 Node.js 24 LTS。')
    environment=skill/'.venv'
    if not environment.exists():
        venv.EnvBuilder(with_pip=True).create(environment)
    python=environment/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    subprocess.run([str(python),'-m','pip','install','numpy==2.3.5'],check=True)
    motion=skill/'assets/motion-canvas'
    run_node_package_tool("npx", ["--yes","pnpm@11.25.0","install","--frozen-lockfile"],motion)
    browser=motion/".browser"
    browser.mkdir(exist_ok=True)
    run_node_package_tool("npm", ["install","--no-audit","--no-fund","--no-save","--prefix",".","playwright-core@1.62.1"],browser)
    subprocess.run(['node',str(motion/'node_modules/typescript/bin/tsc'),'--noEmit'],cwd=motion,check=True)
    print('依赖检查通过。确认安装 Chrome 与剪映专业版，然后重开 Codex。')

def run_node_package_tool(tool,arguments,directory):
    command=(['cmd.exe','/d','/c',tool+'.cmd'] if os.name=='nt' else [shutil.which(tool)])
    subprocess.run(command+arguments,cwd=directory,check=True)

if __name__=='__main__':
    main()

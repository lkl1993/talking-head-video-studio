import {createRequire} from 'node:module';
import {defineConfig} from 'vite';
const require=createRequire(import.meta.url);
export default defineConfig({
  plugins:[require('@motion-canvas/vite-plugin').default({
    project:'./src/project.ts',
    output:process.env.THV_FRAMES ?? './frames'
  })]
});

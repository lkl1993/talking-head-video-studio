import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createServer} from 'vite';

const dir=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const playwright=process.env.THV_PLAYWRIGHT || path.join(dir,'.browser','node_modules','playwright-core');
const {chromium}=require(playwright);
const destination=process.argv[2];
if(!destination) throw Error('用法：node render.mjs <新的输出 MP4 路径>');
const output=path.resolve(destination);
if(fs.existsSync(output)) throw Error('请使用新的输出文件名');
const frames=fs.mkdtempSync(path.join(dir,'.render-'));
process.env.THV_FRAMES=frames;
const config=JSON.parse(fs.readFileSync(path.join(dir,'src/config.json'),'utf8'));
const server=await createServer({root:dir,server:{host:'127.0.0.1',port:0,strictPort:true}});
let browser;
try {
  await server.listen();
  const port=server.httpServer.address().port;
  browser=await chromium.launch(process.env.CHROME_PATH ? {executablePath:process.env.CHROME_PATH} : {channel:'chrome'});
  const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await page.goto('http://127.0.0.1:'+port+'/render.html');
  await page.waitForFunction(() => typeof window.renderLocal==='function');
  await page.evaluate(()=>window.renderLocal());
  const folder=path.join(frames,'animation');
  const files=fs.readdirSync(folder).filter(f=>/^\d+\.jpeg$/.test(f));
  if(files.length!==config.frames) throw Error('导出的帧数与配置不一致：'+files.length);
  const ff=spawnSync('ffmpeg',['-v','error','-nostdin','-n','-framerate',String(config.fps),
    '-i',path.join(folder,'%06d.jpeg'),'-an','-c:v','libx264','-pix_fmt','yuv420p',
    '-vf','scale=out_color_matrix=bt709,setsar=1','-colorspace','bt709','-color_primaries','bt709',
    '-color_trc','bt709','-movflags','+faststart',output],{stdio:'inherit'});
  if(ff.error || ff.status!==0) throw Error('FFmpeg 转码失败',{cause:ff.error});
  console.log(output);
} finally {
  try { await browser?.close(); } finally {
    await server.close();
    fs.rmSync(frames,{recursive:true,force:true});
  }
}

import {Circle, Gradient, Line, Node, Rect, Txt} from '@motion-canvas/2d';

export type Vec = readonly [number, number];
export type Box = readonly [number, number, number, number];
export type Pose = Readonly<{t: number; x: number; y: number; scale: number}>;
export const clamp = (v: number) => Math.max(0, Math.min(1, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (p: number) => {const t = clamp(p); return t*t*(3-2*t);};
export const phase = (time: number, start: number, duration: number) =>
  duration > 0 ? clamp((time-start)/duration) : Number(time >= start);
export const frameAt = (time: number, fps: number) => Math.round(time * fps);

export function poseAt(keys: readonly Pose[], time: number): Pose {
  for (let index=1; index<keys.length; index++) {
    const from=keys[index-1], to=keys[index];
    if (time <= to.t) {
      const progress=smooth(phase(time,from.t,to.t-from.t));
      return {t:time,x:lerp(from.x,to.x,progress),y:lerp(from.y,to.y,progress),scale:lerp(from.scale,to.scale,progress)};
    }
  }
  return keys[keys.length-1];
}

/** Moves layers with one camera gesture, scaled according to relative depth. */
export function cameraPose(layer: Node, time: number, keys: readonly Pose[], depth=1) {
  const pose=poseAt(keys,time);
  layer.position([pose.x*depth,pose.y*depth]);
  layer.scale(1+(pose.scale-1)*depth);
}

export function panel(x: number,y: number,width: number,height: number,fill: string,radius=0) {
  return new Rect({x,y,width,height,fill,radius});
}
export function fullStage(start: string,end: string) {
  return new Rect({x:960,y:540,width:1920,height:1080,fill:new Gradient({
    from:[-960,-540],to:[960,540],stops:[{offset:0,color:start},{offset:1,color:end}]
  })});
}
export function label(text: string,x: number,y: number,size: number,color: string,weight=650) {
  return new Txt({text,x,y,fontSize:size,fill:color,fontFamily:'PingFang SC, Microsoft YaHei, Noto Sans CJK SC, sans-serif',fontWeight:weight});
}
export function stroke(points: Array<[number,number]>,color: string,width=4) {
  return new Line({points,stroke:color,lineWidth:width,lineCap:'round',lineJoin:'round'});
}
export function ball(x: number,y: number,size: number,color: string) {
  return new Circle({x,y,size,fill:color});
}

/** Reveals each glyph on its cue and applies a brief pulse to highlighted characters. */
export function kineticLine(text: string,x: number,y: number,size: number,color: string,accent: string,cues: readonly number[],keywords: readonly string[]=[]){
  const node=new Node({x,y});
  const chars=Array.from(text);
  const boxWidth=size;
  const parts=chars.map((ch,index)=>{
    const hot=keywords.includes(ch);
    const char=label(ch,(index-(chars.length-1)/2)*boxWidth,0,size,hot?accent:color,750);
    node.add(char);
    return {char, hot};
  });
  return {node,update(time: number){
    parts.forEach(({char,hot},index)=>{
      const start=cues[index];
      const p=phase(time,start,.35);
      const boot=1-Math.pow(1-p,3);
      char.opacity(boot);
      char.y(lerp(index%2?-80:82,0,boot));
      const pulse=hot?Math.sin(Math.PI*phase(time,start+.21,.53))*.17:0;
      char.scale(.72+.28*boot+pulse);
      char.rotation((index%2?-1:1)*(1-boot)*13);
    });
  }};
}

/** Segments one process into known nodes, a line, and one moving marker. */
export function timeline(points: Vec[],times: number[],ink: string,muted: string){
  const node=new Node({});
  const coords=points.map(([x,y]):[number,number]=>[x,y]);
  const base=stroke(coords,muted,3);
  const traced=stroke(coords,ink,5);
  const dots=points.map(([x,y])=>ball(x,y,18,ink));
  const marker=ball(points[0][0],points[0][1],34,ink);
  node.add([base,traced,...dots,marker]);
  return {node,update(t: number){
    const poseKeys=points.map(([x,y],i)=>({x,y,t:times[i],scale:1}));
    const pose=poseAt(poseKeys,t);
    marker.position([pose.x,pose.y]);
    dots.forEach((dot,i)=>dot.opacity(.24+.76*smooth(phase(t,times[i]-.18,.32))));
    const lengths=points.slice(1).map(([x,y],i)=>Math.hypot(x-points[i][0],y-points[i][1]));
    const covered=lengths.reduce((sum,len,i)=>sum+len*smooth(phase(t,times[i],times[i+1]-times[i])),0);
    traced.end(clamp(covered/lengths.reduce((a,b)=>a+b,0)));
  }};
}

/** Pivot at a tracked screen-space anchor, travel through the cue poses, then settle. */
export function grip(time: number, cues: readonly Pose[], targetWidth: number,targetHeight: number): Box {
  const pose=poseAt(cues,time);
  const width=targetWidth*pose.scale, height=targetHeight*pose.scale;
  return [pose.x-width/2,pose.y-height,width,height];
}

export function pulseRing(x: number,y: number,color: string) {
  const node=new Circle({x,y,stroke:color,lineWidth:5,size:18});
  return {node,update(time: number,start: number){
    const p=phase(time,start,.43);
    node.opacity(time<start ? 0 : .72*(1-p));
    node.size(20+90*p);
  }};
}

export type LayerPose = Readonly<{x: number; y: number; rotation: number; skew: number; scale: number}>;

/** Animated layers can keep their final poses as the opening state of the next shot. */
export function animateLayer(node: Node, time: number, from: LayerPose, to: LayerPose,
  revealAt: number, moveAt: number, moveDuration: number, lift=0) {
  const visible=smooth(phase(time,revealAt,.42));
  const travel=smooth(phase(time,moveAt,moveDuration));
  node.opacity(visible);
  node.position([lerp(from.x,to.x,travel),lerp(from.y,to.y,travel)-Math.sin(Math.PI*travel)*lift]);
  node.scale(lerp(from.scale,to.scale,travel));
  node.rotation(lerp(from.rotation,to.rotation,travel));
  node.skew.x(lerp(from.skew,to.skew,travel));
}

/** Displays supplied, normalized samples. The caller owns sampling or choosing real data. */
export function waveform(samples: readonly number[],origin: Vec,width: number,height: number,color: string){
  const points=samples.map((value,index):[number,number]=>[
    origin[0]+width*index/(samples.length-1),
    origin[1]-height*Math.min(1,Math.max(-1,value))/2
  ]);
  const node=stroke(points,color,5);
  return {node,update(time: number,begin: number,duration: number){node.end(phase(time,begin,duration));}};
}


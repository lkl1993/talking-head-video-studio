import {makeScene2D, Node} from '@motion-canvas/2d';
import {tween} from '@motion-canvas/core';
import {cameraPose, fullStage, kineticLine, timeline} from './motion';
import config from './config.json';

// A neutral example. Tailor the actual scenes to the episode's spoken content.
export default makeScene2D(function*(view) {
  const stage=new Node({x:-960,y:-540});
  view.add(stage);
  stage.add(fullStage(config.startColor,config.endColor));
  const layer=new Node({});
  stage.add(layer);
  const text=kineticLine(config.title,960,343,100,config.ink,config.accent,
    Array.from(config.title,(_,i)=>.1+i*.065));
  const path=timeline([[340,740],[715,655],[1140,750],[1580,610]],
    [.42,.96,1.64,2.32],config.accent,'#cec5ee');
  layer.add([path.node,text.node]);
  const duration=config.frames/config.fps;
  yield* tween(duration,p=>{
    const t=p*duration;
    text.update(t);
    path.update(t);
    cameraPose(layer,t,[{t:0,x:0,y:0,scale:1},{t:duration,x:-18,y:-12,scale:1.026}],.6);
  });
});

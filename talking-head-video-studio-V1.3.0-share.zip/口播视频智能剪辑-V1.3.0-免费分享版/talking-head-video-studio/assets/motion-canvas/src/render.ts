import {Renderer, RendererResult, Vector2} from '@motion-canvas/core';
import project from './project?project';
import config from './config.json';

async function renderLocal(){
  const r=new Renderer(project);
  let result: RendererResult | undefined;
  r.onFinished.subscribe(v=>result=v);
  await document.fonts.ready;
  await r.render({
    name:'animation',size:new Vector2(1920,1080),fps:config.fps,resolutionScale:1,
    background:config.startColor,colorSpace:'srgb',range:[0,(config.frames-1)/config.fps],
    exporter:{name:'@motion-canvas/core/image-sequence',options:{
      fileType:'image/jpeg',quality:97,groupByScene:false
    }}
  });
  if(result!==RendererResult.Success) throw Error('渲染没有完成');
}
Object.assign(window,{renderLocal});

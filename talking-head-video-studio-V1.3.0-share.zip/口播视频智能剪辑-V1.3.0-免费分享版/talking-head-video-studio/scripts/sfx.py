"""Build independent WAV clips and a frame-aligned three-track mix from actual visual events."""
import argparse
import json
from pathlib import Path
import subprocess as sp
import wave

import numpy as np

RATE=44100
# Seconds, attack and release ms, initial and final Hz, sound mechanism.
PROFILES={
    'reveal': (4/30, 2,36,490,420,'pop'),
    'sweep-up': (9/30,13,98,310,610,'sweep'),
    'connect': (6/30,5,65,535,690,'link'),
    'latch': (5/30,2,48,365,287,'latch'),
    'accent': (5/30,3,58,225,179,'accent'),
    'disconnect': (7/30,6,83,613,326,'disconnect'),
    'sweep-down': (7/30,11,79,650,335,'sweep'),
    'complete': (10/30,7,114,491,656,'finish'),
}

def rows(events,fps,frames):
    if fps<=0 or frames<=0:
        raise ValueError('Positive fps and frame count required')
    result=[]
    last=0
    for event in events:
        f=event['frame']
        sound=event['sound']
        peak=event.get('peak_dbfs',-30)
        pan=event.get('pan',0)
        if type(f) is not int or sound not in PROFILES or not -60<=peak<=-20 or not -1<=pan<=1:
            raise ValueError(f'Invalid event: {event!r}')
        length=max(1,round(PROFILES[sound][0]*fps))
        end=f+length
        if not last<=f<end<=frames:
            raise ValueError(f'Out of range, unordered or overlapping cue at frame {f}')
        last=end
        result.append(dict(event,start_frame=f,end_frame=end,peak_dbfs=peak,pan=pan,
                           file=f'F{f:06d}_{sound}.wav'))
    return result

def audio(path):
    data=sp.check_output(['ffmpeg','-v','error','-nostdin','-i',str(path),'-map','0:a:0',
                         '-ar',str(RATE),'-ac','2','-f','f32le','-'])
    return np.frombuffer(data,dtype='<f4').reshape(-1,2)

def level(x):
    return 20*np.log10(max(1e-10,float(x)))

def tone(sound,n,bias):
    _,attack,release,f0,f1,kind=PROFILES[sound]
    t=np.arange(n)/RATE
    span=n/RATE
    portion=t/span
    phase=2*np.pi*(f0*t+(f1-f0)*t*t/(2*span))
    noise=np.random.default_rng(3*f0+f1).standard_normal(n)
    def smooth(window):
        h=np.hanning(min(window,n))
        return np.convolve(noise,h/h.sum(),'same') if h.sum() else noise
    band=smooth(37)-smooth(111)
    envelope=np.minimum(t/(attack/1000),1)*np.minimum((span-t)/(release/1000),1)
    if kind=='sweep':
        value=(.14*np.sin(phase)+.52*band)*np.exp(-2.2*portion)
    elif kind=='link':
        value=(.47*np.sin(phase)+.11*np.sin(1.56*phase))*np.exp(-23*t)+.18*band*np.exp(-38*t)
    elif kind=='finish':
        age=np.maximum(0,t-.104)
        value=.48*np.sin(2*np.pi*f0*t)*np.exp(-24*t)
        value+=.42*np.minimum(age/.01,1)*np.sin(2*np.pi*f1*age)*np.exp(-18*age)
    elif kind=='disconnect':
        value=(.38*np.sin(phase)+.13*np.sin(1.43*phase))*np.exp(-20*t)+.34*band*np.exp(-46*t)
    else:
        value=(.45*np.sin(phase)+.125*np.sin(1.91*phase))*np.exp(-(34 if kind=='latch' else 42)*t)
        value+=.45*band*np.exp(-115*t)
        if kind=='latch':
            age=np.maximum(0,t-.023)
            value+=.14*(t>=.023)*np.sin(2*np.pi*593*age)*np.exp(-85*age)
    travel=.5+.5*portion if kind=='sweep' else np.ones_like(t)
    channels=(value*envelope)[:,None]*np.column_stack((1-.20*bias*travel,1+.20*bias*travel))
    return channels*.71/max(1e-10,np.max(np.abs(channels)))

def produce(events,args):
    if args.output.exists():
        raise ValueError('Choose a new output directory')
    voice=audio(args.voice)
    picture_samples=round(args.frames*RATE/args.fps)
    if len(voice)<picture_samples-round(RATE/args.fps):
        raise ValueError('Voice shorter than expected picture')
    music=audio(args.music) if args.music else np.empty((0,2),dtype=np.float32)
    length=max(len(voice),picture_samples)
    if len(music)>length:
        raise ValueError('Music bed exceeds output. Prepare and authorize its timing first.')
    baseline=np.zeros((length,2),dtype=np.float32)
    baseline[:len(voice)]=voice
    baseline[:len(music)]+=music
    voice_only=baseline.copy()
    voice_only.fill(0)
    voice_only[:len(voice)]=voice
    mix=baseline.copy()
    material=[]
    for event in events:
        a=round(event['start_frame']*RATE/args.fps)
        b=round(event['end_frame']*RATE/args.fps)
        clip=tone(event['sound'],b-a,event['pan'])
        pcm=np.rint(clip*32767).astype('<i2')
        exact=pcm.astype(np.float32)/32768
        rms=lambda x:level(np.sqrt(np.mean(x.astype(np.float64)**2)))
        voice_rms=rms(voice_only[a:b])
        chosen=event['peak_dbfs']-level(np.max(abs(exact)))
        if voice_rms>-43:
            chosen=min(chosen,voice_rms-14-rms(exact))
        gain=10**(round(chosen,2)/20)
        mix[a:b]+=exact*gain
        event.update(gain_db=round(chosen,2),volume=gain,source='本地原创合成')
        material.append((event,pcm))
    if max(np.max(abs(mix)),np.max(abs(baseline)))>=1:
        raise ValueError('Mix would clip. Recheck baseline and reduce effect gains without touching speech.')
    args.output.mkdir(parents=True)
    for event,pcm in material:
        with wave.open(str(args.output/event['file']),'wb') as out:
            out.setparams((2,2,RATE,0,'NONE','not compressed'))
            out.writeframes(pcm.tobytes())
    sp.run(['ffmpeg','-v','error','-nostdin','-n','-f','f32le','-ar',str(RATE),'-ac','2',
            '-i','pipe:0','-c:a','pcm_f32le',str(args.output/'mix.wav')],input=mix.tobytes(),check=True)
    (args.output/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['plan','build'])
    p.add_argument('--events',type=Path,required=True)
    p.add_argument('--frames',type=int,required=True)
    p.add_argument('--fps',type=float,default=30)
    p.add_argument('--voice',type=Path)
    p.add_argument('--music',type=Path)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    events=rows(json.loads(args.events.read_text()),args.fps,args.frames)
    if args.mode=='build':
        if not args.voice or not args.output:
            p.error('build requires --voice and --output')
        produce(events,args)
    else:
        print(json.dumps(events,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()

"""Plan on frame boundaries. Only the explicit render command writes a preview."""
import argparse
from fractions import Fraction
import json
from pathlib import Path
import re
import subprocess

def mapped(keep, frames):
    result=[]
    cursor=0
    for start,end in keep:
        if not (isinstance(start,int) and isinstance(end,int) and 0<=start<end<=frames):
            raise ValueError(f'Invalid source frame range: {start}, {end}')
        if result and start<result[-1]['source'][1]:
            raise ValueError('Keep ranges must be sorted and non-overlapping')
        result.append(dict(source=[start,end],output=[cursor,cursor+end-start]))
        cursor+=end-start
    if not result:
        raise ValueError('At least one keep range is required')
    return result

def us(timestamp):
    h,m,s,ms=map(int,re.split('[:,.]',timestamp))
    return (h*3600+m*60+s)*1000+ms

def subtitle_map(path,ranges,fps):
    rows=[]
    for block in re.split(r'\n\s*\n',path.read_text(encoding='utf-8-sig').strip()):
        lines=block.splitlines()
        idx=next((i for i,line in enumerate(lines) if ' --> ' in line),None)
        if idx is None:
            continue
        start,end=(round(Fraction(us(ts.split()[0]),1000)*fps) for ts in lines[idx].split(' --> '))
        for row in ranges:
            a,b=row['source']
            left,right=max(a,start),min(b,end)
            if left<right:
                shift=row['output'][0]-a
                rows.append(dict(start_frame=left+shift,end_frame=right+shift,text='\n'.join(lines[idx+1:])))
    return rows

def render(source,output,ranges,fps,full_frames,audio_rate,audio_samples):
    if output.exists() or source.resolve()==output.resolve():
        raise ValueError('Pick a new output file')
    filters=[]
    for i,row in enumerate(ranges):
        a,b=row['source']
        filters.append(f'[0:v]trim=start_frame={a}:end_frame={b},setpts=PTS-STARTPTS[v{i}]')
    # Concat video and audio separately so a fractional audio tail cannot add a picture frame.
    filters.append(''.join(f'[v{i}]' for i in range(len(ranges)))+f'concat=n={len(ranges)}:v=1:a=0[v]')
    for i,row in enumerate(ranges):
        a,b=row['source']
        lo=round(a*audio_rate/fps)
        out_a,out_b=row['output']
        hi=lo+round(out_b*audio_rate/fps)-round(out_a*audio_rate/fps)
        if b==full_frames:
            hi=audio_samples
        fl=f'[0:a]atrim=start_sample={lo}:end_sample={hi},asetpts=PTS-STARTPTS'
        if i:
            fl+=',afade=t=in:d=0.004'
        if i<len(ranges)-1 and hi-lo>audio_rate*.012:
            fl+=f',afade=t=out:st={(hi-lo)/audio_rate-.004:.9f}:d=0.004'
        filters.append(fl+f'[a{i}]')
    filters.append(''.join(f'[a{i}]' for i in range(len(ranges)))+f'concat=n={len(ranges)}:v=0:a=1[a]')
    subprocess.run(['ffmpeg','-v','error','-nostdin','-n','-i',str(source),'-filter_complex',';'.join(filters),
                    '-map','[v]','-map','[a]','-r',str(fps),'-c:v','libx264','-pix_fmt','yuv420p',
                    '-c:a','aac','-b:a','320k','-movflags','+faststart',str(output)],check=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode',choices=['plan','render'])
    ap.add_argument('--keep',type=Path,required=True)
    ap.add_argument('--frames',type=int,required=True)
    ap.add_argument('--fps',type=Fraction,default=Fraction(30))
    ap.add_argument('--srt',type=Path)
    ap.add_argument('--source',type=Path)
    ap.add_argument('--output',type=Path)
    ap.add_argument('--audio-rate',type=int)
    ap.add_argument('--audio-samples',type=int,help='Decoded source audio samples per channel')
    args=ap.parse_args()
    if args.frames<1 or args.fps<=0:
        ap.error('Positive frame count and fps required')
    cuts=mapped(json.loads(args.keep.read_text()),args.frames)
    if args.mode=='render':
        if args.source is None or args.output is None or not args.audio_rate or not args.audio_samples:
            ap.error('render requires --source, --output, --audio-rate and --audio-samples')
        render(args.source,args.output,cuts,args.fps,args.frames,args.audio_rate,args.audio_samples)
    subtitles=subtitle_map(args.srt,cuts,args.fps) if args.srt else []
    print(json.dumps(dict(fps=str(args.fps),original_frames=args.frames,preview_frames=cuts[-1]['output'][1],
                          cuts=cuts,subtitles=subtitles),ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()

"""Prepare a quiet local music bed, with an optional original instrumental."""
import argparse
import json
from pathlib import Path
import subprocess

import numpy as np
from sfx import RATE, audio

def original(n):
    t=np.arange(n)/RATE
    beat=60/94
    measure=np.floor(t/(4*beat)).astype('int32')
    age=np.mod(t,beat/2)
    notes=np.array([[50,57,62,65],[46,53,58,62],[53,60,65,69],[48,55,60,64]])
    frequencies=440*2.0**((notes-69)/12)
    root=frequencies[measure%4,0]
    env=np.sin(np.pi*np.mod(t,4*beat)/(4*beat))**.6
    pad=env*(.27*np.sin(2*np.pi*root*t)+.15*np.sin(2*np.pi*root*1.5*t))
    pitch=frequencies[measure%4,(np.floor(t/(beat/2)).astype('int32')+1)%4]
    bell=.13*np.sin(2*np.pi*pitch*age)*np.exp(-13*age)*np.minimum(1,age/.018)
    return np.column_stack((pad+.94*bell,pad+1.06*bell))

def build(args):
    n=round(args.frames*RATE/args.fps)
    if n<1 or args.fps<=0 or args.frames<=0 or args.output.exists():
        raise ValueError('Use a positive timeline and a new output path')
    voice=audio(args.voice)
    if len(voice)<n-round(RATE/args.fps):
        raise ValueError('Voice shorter than expected picture')
    if args.source:
        span=audio(args.source)
        a=round(args.offset*RATE)
        if not 0<=a<=len(span)-n:
            raise ValueError('Selected music source range does not cover the project')
        bed=span[a:a+n].astype('float64')
    else:
        bed=original(n)
    voice_level=np.sqrt(np.mean(voice.astype('float64')**2))
    bed_level=np.sqrt(np.mean(bed**2))
    gain=(voice_level/max(bed_level,1e-10))*10**(-args.margin_db/20)
    curve=np.ones(n,dtype='float64')
    fade=min(n//4,RATE)
    if fade:
        curve[:fade]*=np.linspace(0,1,fade)
        curve[-fade:]*=np.linspace(1,0,fade)
    if args.duck:
        ranges=json.loads(args.duck.read_text())
        ease=round(.18*RATE)
        for start,end,decibels in ranges:
            a,b=round(start*RATE/args.fps),round(end*RATE/args.fps)
            if not 0<=a<b<=n or not -60<=decibels<=0:
                raise ValueError(f'Invalid music attenuation range: {start}, {end}, {decibels}')
            lo=max(0,a-ease)
            hi=min(n,b+ease)
            target=10**(decibels/20)
            curve[a:b]=np.minimum(curve[a:b],target)
            curve[lo:a]=np.minimum(curve[lo:a],np.linspace(1,target,a-lo))
            curve[b:hi]=np.minimum(curve[b:hi],np.linspace(target,1,hi-b))
    bed*=gain*curve[:,None]
    overlap=min(n,len(voice))
    added=voice[:overlap]+bed[:overlap]
    if max(np.max(abs(added)),np.max(abs(bed)))>=1:
        raise ValueError('Music would clip, increase --margin-db')
    subprocess.run(['ffmpeg','-v','error','-nostdin','-n','-f','f32le','-ar',str(RATE),'-ac','2',
                    '-i','pipe:0','-c:a','pcm_f32le',str(args.output)],input=bed.astype('<f4').tobytes(),check=True)
    print(json.dumps(dict(source=str(args.source) if args.source else 'local original',
                          gain_db=float(20*np.log10(max(gain,1e-10))),samples=n)))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--voice',type=Path,required=True)
    p.add_argument('--frames',type=int,required=True)
    p.add_argument('--fps',type=float,default=30)
    p.add_argument('--source',type=Path,help='An authorized instrumental, otherwise use local original')
    p.add_argument('--offset',type=float,default=0)
    p.add_argument('--margin-db',type=float,default=16)
    p.add_argument('--duck',type=Path,help='JSON list of [start_frame,end_frame,attenuation_db]')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.fps<=0 or a.margin_db<10:
        p.error('Use positive fps and a speech margin of at least 10 dB')
    build(a)

"""Plan or build an independent Jianying draft from a project-relative manifest."""
import argparse
from fractions import Fraction
import json
from pathlib import Path
import shutil
import sys
import time
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import pyJianYingDraft as jy

TRACKS=('真人原声','背景音乐','动作音效')

def load(path):
    return json.loads(path.read_text())

def write(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

def prepare(manifest):
    doc=load(manifest)
    fps=doc.get('fps',30)
    frames=doc['frames']
    if type(fps) is not int or fps<1 or type(frames) is not int or frames<1:
        raise ValueError('Use positive integer fps and frame count')
    width,height=doc.get('size',[1920,1080])
    if not all(type(n) is int and n>0 and n%2==0 for n in (width,height)):
        raise ValueError('Use positive even canvas dimensions')
    timelines={}
    for trackname,items in doc['video'].items():
        if trackname in TRACKS or trackname=='独立字幕':
            raise ValueError(f'Reserved track name: {trackname}')
        timelines[trackname]=items
    if not timelines or not next(iter(timelines.values())):
        raise ValueError('The base video track must be present first')
    audio=doc.get('audio',{})
    if not audio.get('voice'):
        raise ValueError('The independent voice track is required')
    for k,name in zip(('voice','music','sfx'),TRACKS):
        timelines[name]=audio.get(k,[])
    start_end=lambda frame:round(Fraction(frame*1000000,fps))
    result=dict(timelines={},fps=fps,size=[width,height],frames=frames)
    for trackname,items in timelines.items():
        planned=[]
        last=0
        for item in items:
            original=Path(item['path'])
            source=(manifest.parent/original).resolve()
            if not source.is_file():
                raise ValueError(f'Media not readable: {source}')
            a,b=item['frames']
            v=trackname not in TRACKS
            if not (type(a) is int and type(b) is int and last<=a<b<=frames):
                raise ValueError(f'Clip crosses overlap or end of timeline: {trackname} {a}, {b}')
            last=b
            f=item.get('source_frame',0)
            if type(f) is not int or f<0:
                raise ValueError('Source frame must be a non-negative integer')
            end=start_end(b)
            extra=item.get('audio_tail_us',0)
            if extra:
                if trackname!=TRACKS[0] or b!=frames or not 0<extra<1000000/fps:
                    raise ValueError('Subframe tail only belongs to the final voice clip')
                end+=extra
            gain=item.get('volume',0 if v else 1)
            if not 0<=gain<=2 or (v and gain!=0):
                raise ValueError('Only the independently mixed audio tracks can carry sound')
            box=item.get('box')
            if box:
                x,y,w,h=box
                if not v or not (x>=0 and y>=0 and w>0 and h>0 and x+w<=width and y+h<=height):
                    raise ValueError('Box must fit the video canvas')
            planned.append(dict(path=str(source),start=start_end(a),duration=end-start_end(a),
                                source=start_end(f),gain=gain,box=box))
        result['timelines'][trackname]=planned
    subs=doc.get('srt')
    if subs and doc.get('burned_subtitles'):
        raise ValueError('Prevent duplicate burned-in and independent subtitles')
    if subs:
        target=(manifest.parent/subs).resolve()
        if not target.is_file():
            raise ValueError(f'Subtitles not readable: {target}')
        result['srt']=str(target)
    else:
        result['srt']=None
    return result

def metadata(folder,source,content):
    file=folder/'draft_meta_info.json'
    meta=load(file)
    now=time.time_ns()//1000
    meta.update(draft_id=content['id'],draft_name=folder.name,draft_fold_path=str(folder),
                draft_root_path=str(folder.parent),tm_duration=content['duration'])
    if source is None:
        meta.update(tm_draft_create=now,tm_draft_modified=now)
    write(file,meta)

def verify(folder):
    d=load(folder/'draft_info.json')
    materials={m['id']:m for kind in ('videos','audios') for m in d['materials'][kind]}
    for material in materials.values():
        p=Path(material['path'])
        if p.parent!=folder/'materials' or not p.is_file():
            raise ValueError(f'Invalid independent media reference: {p}')
    for track in d['tracks']:
        if track['type']!='text' and any(s['material_id'] not in materials for s in track['segments']):
            raise ValueError(f'Missing material in {track["name"]}')
    return d

def build(plan,folder):
    if folder.exists() or folder.is_symlink() or not folder.parent.is_dir():
        raise ValueError('Use a new name under an existing output directory')
    w,h=plan['size']
    project=jy.DraftFolder(str(folder.parent)).create_draft(folder.name,w,h,fps=plan['fps'],allow_replace=False)
    project.content['id']=str(uuid.uuid4()).upper()
    media_dir=folder/'materials'
    media_dir.mkdir()
    copied={}
    material_cache={}
    for k,(name,items) in enumerate(plan['timelines'].items()):
        video=name not in TRACKS
        project.add_track(jy.TrackType.video if video else jy.TrackType.audio,name,relative_index=k)
        for item in items:
            source=Path(item['path'])
            key=(source,video)
            if key not in copied:
                dest=media_dir/f'{len(copied)+1:03d}_{source.name}'
                shutil.copyfile(source,dest)
                copied[key]=dest
                factory=jy.VideoMaterial if video else jy.AudioMaterial
                material_cache[key]=factory(str(copied[key]))
            asset=material_cache[key]
            target=jy.Timerange(item['start'],item['duration'])
            src=jy.Timerange(item['source'],item['duration'])
            if src.end>asset.duration and src.end-asset.duration<=1:
                asset.duration=src.end
            if video:
                settings=jy.ClipSettings()
                if item['box']:
                    x,y,bw,bh=item['box']
                    fit=min(w/asset.width,h/asset.height)
                    settings=jy.ClipSettings(scale_x=bw/(asset.width*fit),scale_y=bh/(asset.height*fit),
                                             transform_x=(x+bw/2-w/2)/(w/2),transform_y=(h/2-y-bh/2)/(h/2))
                seg=jy.VideoSegment(asset,target,source_timerange=src,volume=0,clip_settings=settings)
            else:
                seg=jy.AudioSegment(asset,target,source_timerange=src,volume=item['gain'])
            project.add_segment(seg,name)
    if plan['srt']:
        src=Path(plan['srt'])
        srt=folder/'original-subtitles.srt'
        shutil.copyfile(src,srt)
        project.import_srt(str(srt),'独立字幕')
    project.save()
    metadata(folder,None,verify(folder))

def install(archive,root):
    verify(archive)
    folder=root/archive.name
    if not root.is_dir() or folder.exists() or folder.is_symlink():
        raise ValueError('Inaccessible draft root or name already exists')
    index=root/'root_meta_info.json'
    if index.is_file():
        for row in load(index).get('all_draft_store',[]):
            if row.get('draft_name','').casefold()==folder.name.casefold() or Path(row.get('draft_fold_path','')).name==folder.name:
                raise ValueError('Draft name already in the Jianying index')
    shutil.copytree(archive,folder)
    content=load(folder/'draft_info.json')
    for kind in ('videos','audios'):
        for asset in content['materials'][kind]:
            asset['path']=str(folder/'materials'/Path(asset['path']).name)
    write(folder/'draft_info.json',content)
    metadata(folder,archive,verify(folder))
    return folder

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['plan','build','install'])
    p.add_argument('--manifest',type=Path)
    p.add_argument('--archive',type=Path)
    p.add_argument('--root',type=Path)
    a=p.parse_args()
    if a.mode=='install':
        if not a.archive or not a.root:
            p.error('install requires --archive and --root')
        print(install(a.archive.resolve(),a.root.resolve()))
        return
    if not a.manifest:
        p.error('plan and build require --manifest')
    plan=prepare(a.manifest.resolve())
    if a.mode=='build':
        if not a.archive:
            p.error('build requires --archive')
        build(plan,a.archive.resolve())
    else:
        print(json.dumps(plan,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()

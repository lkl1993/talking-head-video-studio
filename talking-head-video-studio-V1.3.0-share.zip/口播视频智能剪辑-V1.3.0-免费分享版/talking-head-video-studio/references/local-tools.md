# 本机工具与路径

从本 Skill 目录相对定位附带脚本与组件，从本期项目配置获取视频、字幕、音乐、授权和输出位置。新项目本机工具路径可从 `PATH`、已有工具安装说明或当前工作区配置发现。记录版本及相对来源，避免绑定用户目录、机器账号和历史任务编号。

- FFmpeg、FFprobe 用于探测、抽帧、精剪、H.264/AAC 和解码。剪映生成器使用包内 Apache-2.0 授权的 pyJianYingDraft 副本，媒体探测可以直接走 FFprobe。见[剪映](jianying.md)。
- Python 3.11+。音效脚本需要已有 NumPy。分享版安装脚本的 --setup 为 Skill 建立独立 .venv。macOS 用 .venv/bin/python，Windows 用 .venv/Scripts/python.exe。已有可用解释器与 NumPy 时可直接使用。
- 本机转写优先复用可运行的 whisper.cpp 与已缓存模型。只读定位二进制及模型，从当前项目生成 16 kHz 单声道临时音频，指定实际语言并导出有时间码的文本。无模型或不能可靠识别关键短句时请求原 SRT 或文本。
- 动效使用本机已有 Motion Canvas 3.17.2、Node、Chrome、FFmpeg。分享版包含锁定依赖的渲染工程，说明见[组件](motion-components.md)。把源码用于当期工程，渲染结果输出到当期目录。MotionGit 原生本地验签和控件入口见[模板](motiongit.md)。两者通过本期参数和视频片段交接。
- 剪映草稿库由本机设置获取，以已验证版本为参考。读取当前界面确认操作对象是本期唯一草稿。素材路径在交付目录下，迁移时重新链接或用当期草稿工具重建。

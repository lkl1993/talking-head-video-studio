# MotionGit 现代图文控件

分享包不含个人版模板、helper、运行时缓存或第三方素材。有需要时在官方作者页面以自己的账号获取，选择 16:9 横屏版，按随包指南在自己的工程中使用。历史兼容性验证针对 2.7.18-alpha.14，其他版本先以合同和本地预览检查。外层为 .motion ZIP、公开指南及 helper。受保护内层由本地 helper 执行，运行报告显示 motion-kit 0.3.0 使用 HTML、JS、CSS 和 Chrome。它与 Motion Canvas 3.17.2 有不同的工程和渲染接口。兼容边界是经过检查的 MP4、秒制参数以及可观察的动效机制。

## 用本地安装验证控件

沿用已安装 Node.js、Chrome、FFmpeg 和 verified cache。用随包 `assistant/motion.mjs --offline`。先用 `start <原 .motion> --summary` 核验版本和签名，再用 `contract <原 .motion> motion-kit <控件名…>` 读取当前参数。另建空测试实例。用合同返回的 `check-params → plan → prepare → preview → render` 在实例目录中生产，`--out` 先指向实例内部。检查计划和实际预览后再导出。遇到浏览器缺项可把 `CHROME_PATH` 指向已有 Chrome。遇到缓存或本地解锁缺失，记录真实错误，按已验证的 Motion Canvas 路线继续独立工作。

[原生秒制控件示例](../assets/motiongit-kit-example.json)已在本机跑通。新项目复制后替换标题、节点、秒制区间与 cue，并重新走检查和预览。只有参数和示例文本存在于此文件，运行时仍由本机已安装的模板提供。

已通过本机原生预览与导出的是以下三项。控制器完整清单只作为待验证库存。

| 现有控件 | 已观察的动作 | 本 Skill 相应实现 |
| --- | --- | --- |
| `title/type` | 第一行逐字出现，第二行成为重音 | `kineticLine` 在指定字的节拍分别控制入场、字号和落点 |
| `fusion/orbit` | 轨道上的对象靠拢，落到最终组合状态 | 用同一坐标与秒制状态驱动对象组装，用 `cameraPose` 给前后两层提供差速 |
| `flow/branch` | 从起点描线，再进入分支节点 | 用 `timeline` 推动一个有语义的对象，按口播到达节点；真实并行分支另画路径 |

`kenburns/parallax`、`spotlight/magnifier`、`timeline/horizontal` 已核对参数，原生导出未实测。根据可观察效果用本 Skill 的组件搭建项目镜头。涉及真实图片或视频时传入本期已核权文件。原生完整场景、全部控件、真实视频人物追踪和第三方素材兼容仍须分开实测。

## 来源与授权

本地核验的 `licenses/TEMPLATE-LICENSE.txt` 载明模板代码 MIT 及版权方阿杜Next。个人 .motion 内含账号绑定信息，引用时仅保存模板名、版本、公开来源和许可证据。受保护源码通过已声明的本地接口使用。只有能合法取得相应可读源码、确认许可适用于该文件、保留应附版权与许可时才移植代码。每项第三方字体、图标、照片、视频、音乐和音效分别登记来源、文件、用途、商用与再分发条件和署名。

运行清单登记了 Geist、Noto Sans SC、Noto Sans Mono 的 OFL 文件，也有各类音效与主题素材。清单不能单独为未知第三方媒体授权。本 Skill 的组件使用独立编写的几何图形、机器已有字体和已获准的本期素材。账号凭据、缓存与个人包保留在用户自己的机器。没有模板时使用包内 Motion Canvas 组件，覆盖上述核心动画表达。

[MotionGit 605 模板与许可](https://motiongit.com/@adunext/template-01-integrated) · [公开技术资料 336980](https://github.com/motiontemplates/336980)
